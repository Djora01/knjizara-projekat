<?php

function redirect($url) {
	if ($url == '') return;
	header("location: {$url}");
	exit;	
}

$db = mysqli_connect('localhost', 'root', '', 'knjizara');

?>