<?php
// Definiranje konstanti za putanje
define('DIR_ROOT', './');
define('DIR_CORE', DIR_ROOT . 'core/');
define('DIR_MODULES', DIR_ROOT . 'modules/');
define('DIR_PUBLIC', DIR_ROOT . 'public/');
define('DIR_PUBLIC_JS', DIR_PUBLIC . 'js/');
define('DIR_PUBLIC_CSS', DIR_PUBLIC . 'css/');
define('DIR_PUBLIC_IMAGES', DIR_PUBLIC . 'images/');
define('DIR_VIEW', DIR_ROOT . 'template/');
define('URL_INDEX', DIR_ROOT . 'index.php');


include DIR_CORE . 'functions.php';

$_app = [
	'action' => $_GET['action'] ?? '',
	'id' => (int)($_GET['id'] ?? ''),
];

$_page_view = [
	'page_title' => '',
	'_error' => [],
	'_message' => [],
	'_data' => []
];

session_start();

$module = $_GET['module'] ?? '';

$model_filename = '';


$model_filename = DIR_MODULES . "model-{$module}.php";
if ($module == '') $model_filename = DIR_MODULES . 'model-latest.php';


include($model_filename);

include DIR_VIEW . 'header.php';
if (isset($_page_view['view_filename']) && $_page_view['view_filename'] != '')
	include($_page_view['view_filename']);
include DIR_VIEW . 'footer.php';

?>
