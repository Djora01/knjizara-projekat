-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2024 at 02:09 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `knjizara`
--

-- --------------------------------------------------------

--
-- Table structure for table `knjige`
--

CREATE TABLE `knjige` (
  `id` int(11) NOT NULL,
  `naslov` varchar(50) NOT NULL,
  `autor` varchar(50) NOT NULL,
  `datum` year(4) NOT NULL,
  `opis` varchar(255) NOT NULL,
  `slika` varchar(200) NOT NULL,
  `cena` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `knjige`
--

INSERT INTO `knjige` (`id`, `naslov`, `autor`, `datum`, `opis`, `slika`, `cena`) VALUES
(1, 'ATOMSKE NAVIKE', 'DZEJMS KLIR', '2019', 'Knjiga \"Atomske navike\" Džejmsa Klira pripada žanru psihologije uspeha i od svog prvog objavljivanja pre manje od godinu dana postala je bestseler u toj oblasti. Ona će se ove godine naći na policama u čak 40 zemalja širom sveta! Džejms Klir, jedan od vod', './public/images/book-1.jpg', '950 dinara'),
(2, 'POSLEDNJI SATI', 'JELENA BAČIĆ ALIMPIĆ', '2014', 'Na prvi pogled, Katarina Safran je oličenje uspeha. Njeno ime je sinonim za veštinu, stručnost i neumornu posvećenost medicinskom pozivu i kardiohirurgiji. Njen um je besprekoran, a ruke sigurne u operacionoj sali. Udata za uspešnog francuskog biznismena,', './public/images/book-2.jpg', '759 dinara'),
(3, 'DOK SE KAFA NE OHLADI', 'TOŠIKAZU KAVAGUČI', '1989', 'U Japanu, već više od sto godina, postoji jedan sasvim poseban kafić, i za njega se vezuje na hiljadu legendi.\r\n\r\nPriča se da, kad jednom uđete u njega, nikada ne izađete isti. Priča se da, dok pijete kafu, možete ponovo da proživite trenutak iz sopstveno', './public/images/book-3.jpg', '1359 dinara'),
(4, 'DECA ZLA', 'MIODRAG MAJIĆ', '2012', 'U središtu romana Deca zla nalazi se dramatično ubistvo, a potraga za počiniocem biće samo okidač za niz drugih događaja koji će otkriti da je reč o zločinu strasti, osvete, opomene i simbolike.\r\n\r\nKako pronaći krivca u svetu u kom je istina izobličena, a', './public/images/book-4.jpg', '1100 dinara'),
(5, 'OSTRVO PELIKANA', 'MIODRAG MAJIĆ', '2007', 'Knjiga \"Atomske navike\" Džejmsa Klira pripada žanru psihologije uspeha i od svog prvog objavljivanja pre manje od godinu dana postala je bestseler u toj oblasti. Ona će se ove godine naći na policama u čak 40 zemalja širom sveta! Džejms Klir, jedan od vod', './public/images/book-5.jpg', '780 dinara'),
(6, 'MESEC BEZ MEDA', 'KRISTINA LOREN', '2023', 'Medeni mesec iz snova… sa zakletim neprijateljem!\r\nOliv nikada nema sreće, ali je zato njena identična sestra bliznakinja Ejmi, s druge strane, verovatno najsrećnija osoba na svetu. Dok se sprema da se uda za muškarca iz snova, Oliv je primorana da se l', './public/images/book-6.jpg', '1399 dinara'),
(7, '48 ZAKONA MOĆI', 'ROBERT GRIN', '1999', 'Ova nemoralna, prevrtljiva, nemilosrdna, podređujuća i prodorna knjiga destilira tri hiljade godina istorije moći u 48 brutalnih i veoma jasno objašnjenih zakona. Ovde ćete naći sve one ljude koji su se tokom istorije u svojim razmišljanjima dotakli teme ', './public/images/book-7.jpg', '599 dinara'),
(8, 'RUDNIK', 'MIODRAG MAJIĆ', '2015', 'U središtu ove knjige nalazi se junak koji će vas od prve do poslednje stranice voditi kroz sopstvena sećanja. Kako ovu priču priča iz sanatorijuma, sve što bude kazao biće dovedeno u pitanje i podvrgnuto dodatnom preispitivanju. Međutim, to ga neće spreč', './public/images/book-8.jpg', '890 dinara'),
(9, 'LJUDI KOJI VOLE KNJIGE', 'EMILI HENRI', '2019', 'Jedno leto. Dva rivala. Zaplet kakav nisu mogli ni da zamisle.\r\nŽivot Nore Stivens je poput knjiga koje opsesivno čita, ali ona nije klasična heroina, naprotiv. Nije odvažna i neustrašiva, nije devojka iz snova, a posebno nije mila i draga. U stvari, ona ', './public/images/book-9.jpg', '670 dinara'),
(10, 'SREĆA NA NOĆNOM STOČIĆU', 'ALBERTO SIMONE', '2013', 'Ko ne želi da bude srećan? Ko ne želi da ljudi koje voli budu srećni? Ko bar jednom u životu nije doživeo trenutak sreće, te proveo godine negujući nostalgično sećanje na taj momenat?\r\nMeđutim, stranice knjige Sreća na noćnom stočiću govore o trajnoj sreć', './public/images/book-10.jpg', '800 dinara'),
(11, 'PREGOVORI SA STVARNOŠĆU', 'ERLEND LU', '2002', 'Lični i očaravajući esej u stilu Biti Džon Mekinro, ili O Čemu govorim kada govorim o trčanju Harukija Murakamija!\r\n\r\nSa entuzijazmom i oštrog oka, Erlend Lu nas vodi na jednogodišnju odiseju na jednom točku. Sa slobodnim asocijacijama, razigrano, ali uve', './public/images/book-11.jpg', '690 dinara'),
(12, 'USAMLJENI KAPETAN', 'ALEKSA ASTON', '1987', 'Usamljeni kapetan koji iznenada postaje vojvoda.\r\nĆerka plemića koja vodi imanje, jer njen otac to više ne može.\r\nDve usamljene duše između kojih sevaju varnice…\r\nMajls Notli se vraća kući kao novi vojvoda od Vinsloua, nakon što je prognan pod optužbom da', './public/images/book-12.jpg', '760 dinara'),
(13, 'KĆI ITALIJE', 'SORAJA LEJN', '1976', 'ITALIJA, 1946.\r\nDok se oprašta od Feliksa, srce joj se slama. Kada su u detinjstvu trčali kaldrmom, sa rukom u ruci, Este je verovala da se nikada neće rastati. Ali mesto balerine u čuvenom pozorištu Skala u Milanu ponuda je koju ne može da odbije, a to ć', './public/images/book-13.jpg', '800 dinara'),
(14, 'VIDIMO SE U AVGUSTU', 'GABRIJEL GARSIJA MARKES', '1976', 'Ana Magdalena Bać živi mirnim, uređenim, porodičnim životom. Ima muža i dvoje dece, i svake godine, istog avgustovskog dana, odlazi trajektom do ostrva na kom je njena majka tražila da bude sahranjena da odnese gladiole na njen grob. Te posete ostrvu neoč', './public/images/book-14.jpg', '960 dinara'),
(15, 'DEVET POTPUNIH STRANACA', 'LIJAN MORIJARTI', '2009', 'Devet stranaca. Jedna kuća. Deset dana koji če im zauvek promeniti živote. Devet potpunih stranaca umornih od gradskog života okuplja se u izolovanom odmaralištu. Neki su došli da bi smršali, drugi da bi ponovo pokrenuli svoj život, a ima i onih koji krij', './public/images/book-15.jpg', '580 dinara'),
(16, 'MAJSTOR ZAGONETKE', 'DANIJELA TRUSONI', '2016', 'Čitav svet je zagonetka, a Majk Brink – slavni i genijalni enigmatičar – razume njihove obrasce bolje nego bilo ko drugi.\r\n\r\nNekada fudbalska zvezda u usponu, Brink je doživeo povredu koja je izazvala retko medicinsko stanje: sindrom savanta. Stekao je me', './public/images/book-16.jpg', '999 dinara'),
(17, 'NOĆ SNEGA I KRVI', 'TRINA VOLŠ', '2005', 'Ledeno novogodišnje veče. Sneg prekriva Irsku šibanu vetrom dok divlji okean besni.\r\n\r\nŠestoro prijatelja se okuplja. Prošlo je deset godina od tragedije koja ih je razdvojila. Mnogo toga može da se promeni za jednu deceniju…\r\n\r\nVeze iz detinjstva sada su', './public/images/book-17.jpg', '1260 dinara'),
(18, 'ČETIRI PERA', 'A.E.V MEJSON', '2018', 'Pred sam odlazak u Sudan, britanski oficir Hari Feveršam odlučuje da napusti vojsku.\r\n\r\nUbrzo dobija četiri bela pera – simbol kukavičluka - od svoja tri najbolja prijatelja i verenice.\r\n\r\nDa bi osvetlao obraz, Hari se preruši u Arapina i odlazi u Sudan, ', './public/images/book-18.jpg', '1599 dinara'),
(19, 'KUĆA SVETLOSTI', 'DONATO KARIZI', '2021', 'Sakrij se. Ne pomeraj se. Ne diši. Jer oni te traže.\r\n\r\nU velikoj, trošnoj kući na vrhu brda jedna devojčica živi sama…\r\n\r\nZove se Eva, ima deset godina, a sa njom su samo guvernanta i au pair devojka, Finkinja Maja Salo. Od roditelja nema ni traga. Maja ', './public/images/book-19.jpg', '899 dinara');

-- --------------------------------------------------------

--
-- Table structure for table `kontakt`
--

CREATE TABLE `kontakt` (
  `id` int(11) NOT NULL,
  `ime` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `poruka` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `korisnici`
--

CREATE TABLE `korisnici` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `usertype` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `korisnici`
--

INSERT INTO `korisnici` (`id`, `username`, `password`, `usertype`) VALUES
(1, 'veljkodjoric01', 'zeljko123', ''),
(2, 'admin', '1234', 'admin'),
(3, 'user', '1234', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `knjige`
--
ALTER TABLE `knjige`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kontakt`
--
ALTER TABLE `kontakt`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `korisnici`
--
ALTER TABLE `korisnici`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `knjige`
--
ALTER TABLE `knjige`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `kontakt`
--
ALTER TABLE `kontakt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `korisnici`
--
ALTER TABLE `korisnici`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
