<?php

// Dohvaćanje knjiga iz baze podataka
$sql = "SELECT * FROM knjige order by `datum` desc";
$result = $db->query($sql);

if ($result->num_rows > 0) {
    // Prikaz knjiga u obliku tablice
    while ($row = $result->fetch_assoc()) {
        $_page_view['_data'][] = $row;
    }
} else {
    
}
$_page_view['view_filename'] = './template/body.php';


if ($_app['action'] != '') {
	switch($_app['action']) {
		case 'submit':
			if ($_POST) {
				if (($_POST['cancel'] ?? '') == 1)
					redirect(URL_INDEX . '?module=books');

				$news_title = $_POST['naslov'];
				$news_short = $_POST['autor'];
				$news_description = $_POST['opis'];
				$news_date = date('Y-m-d');

				$sql = "INSERT INTO `knjige` 
							(`naslov`, `autor`, `datum`, `opis`, `slika`) 
						VALUES
							('{$naslov}', '{$autor}', '{$opis}', '{$news_date}')";
				mysqli_query($db, $sql);
				redirect(URL_INDEX . '?module=books');
			}
			//$_page_view['breadcrumbs']['./index.php?module=book'] = 'Knjige';
			$_page_view['page_title'] = 'Unos novog članka';
			$_page_view['view_filename'] = './template/view-news-submit.php';
			break;
		case 'edit':
			if ($_POST) {
				if (($_POST['cancel'] ?? '') == 1)
					redirect(URL_INDEX . '?module=book');

				$naslov = $_POST['naslov'];
				$autor = $_POST['autor'];
				$opis = $_POST['opis'];

				$sql = "UPDATE `knjige` SET
							`naslov` = '{$naslov}',
							`autor` = '{$autor}',
							`opis` = '{$opis}'
						WHERE
							`id` = {$_app['id']}
						LIMIT 1";
				mysqli_query($db, $sql);
				redirect(URL_INDEX . '?module=books');
			}
			$sql = "SELECT *
					FROM `knjige`
					WHERE `id`={$_app['id']}
					LIMIT 1
				";
			$result = mysqli_query($db, $sql);
			$article = mysqli_fetch_assoc($result);
			$_page_view['breadcrumbs']['./index.php?module=books'] = 'Knjige';
			$_page_view['page_title'] = 'Izmena članka';
			$_page_view['view_filename'] = './template/view-book-submit.php';
			break;
		case 'delete':
			if ($_POST) {
				if (isset ($_POST['confirm_action']) ) {
					$sql = "DELETE FROM `knjige` WHERE `id`={$_app['id']} LIMIT 1";
					mysqli_query($db, $sql);
					redirect(URL_INDEX . '?module=books');
				}
				else if (!isset ($_POST['confirm_action']) )
					redirect(URL_INDEX . '?module=books');
			}
			
			$sql = "SELECT `naslov` FROM `knjige` WHERE `id`={$_app['id']} LIMIT 1";
			$result = mysqli_query($db, $sql);
			$row = mysqli_fetch_assoc($result);
			$_page_view['admin_confirmation'] = 1;
			//$_page_view['breadcrumbs']['./index.php?module=books'] = 'Knjige';
			$_page_view['page_title'] = $row['naslov'];
			$_page_view['view_filename'] = './template/view-book-delete.php';
			break;
	}
}
else {
	if ($_app['id'] > 0) {
		$article = [];
		$sql = "SELECT *
				FROM `knjige`
				WHERE `id`={$_app['id']}
				LIMIT 1
			";
		$result = mysqli_query($db, $sql);
		$article = mysqli_fetch_assoc($result);
		
		if (empty($article))
			redirect(URL_INDEX . '?module=error404');

		$_page_view['page_title'] = $article['naslov'];
		//$_page_view['breadcrumbs']['./index.php?module=books'] = 'Knjige';
		$_page_view['view_filename'] = './template/view-books-article.php';
	}
	else {
		$books = [];
		$sql = "SELECT * 
				FROM `knjige`
				ORDER BY 
					`datum` DESC
					
				";
		$result = mysqli_query($db, $sql);
		while ($row = mysqli_fetch_assoc($result)) {
			$books[] = $row;
		}

		$_page_view['page_title'] = 'Knjige';
		$_page_view['view_filename'] = './template/body.php';
	}
}
$db->close();
?>
