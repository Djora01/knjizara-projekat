<?php
$id = $_GET['id'];
// Dohvaćanje knjiga iz baze podataka
$sql = "SELECT * FROM knjige WHERE `id` = $id";
$result = $db->query($sql);

$row = mysqli_fetch_assoc($result);
$_page_view['_data'][] = $row;
//var_dump($_page_view['_data']);
$_page_view['view_filename'] = './template/view-book.php';

$db->close();
?>