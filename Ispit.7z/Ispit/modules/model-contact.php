<?php

if ($_POST) {
    $ime = $_POST['ime'];
    $email = $_POST['email'];
    $poruka = $_POST['poruka'];

    if ($ime == '')
        $_page_view['_error'][] = 'Unesite vaše ime';
    if ($email == '')
        $_page_view['_error'][] = 'Unesite email adresu';
    if ($poruka == '')
        $_page_view['_error'][] = 'Unesite poruku';

}
if(isset($_POST["submit"])){
    $ime=$_POST["ime"];
    $email=$_POST["email"];
    $poruka=$_POST["poruka"];

    $query="INSERT INTO kontakt (ime,email,poruka) VALUES ('$ime','$email','$poruka')";
    mysqli_query($db,$query);
}
$_page_view['page_title'] = 'Kontakt';
$_page_view['view_filename'] = DIR_VIEW . 'view-contact.php';
 
?>