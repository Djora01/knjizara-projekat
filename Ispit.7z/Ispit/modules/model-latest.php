<?php
// Dohvaćanje knjiga iz baze podataka
$sql = "SELECT * FROM knjige ORDER BY datum DESC LIMIT 5";
$result = $db->query($sql);
$_naslov = 'najnovije knjige';

if ($result->num_rows > 0) {
    // Prikaz knjiga u obliku tablice
    while ($row = $result->fetch_assoc()) {
        $_page_view['_data'][] = $row;
    }
} else {
    
}
$_page_view['view_filename'] = './template/body.php';
// Zatvaranje poveznice s bazom podataka
$db->close();
?>

