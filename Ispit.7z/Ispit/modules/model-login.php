<?php

//register();

if (($_GET['action'] ?? '') == 'logout') {
    unset($_SESSION['login_status']);
    unset($_SESSION['usertype']);
    redirect(URL_INDEX);
}
if (($_SESSION['login_status'] ?? '') == 1) {
    $_page_view['_message'][] = 'Već ste ulogovani';
}
else if ($_POST) {
    $username = $_POST['user'];
    $password = $_POST['password'];

    if(empty(trim($username))){
        echo $username_error ="Polje ime je prazno";
    }else{
        if(empty(trim($password))){
            echo $password_error ="Polje za sifru je prazno";
        }
    }

    if ($username == '' && $password == '') {
        $_page_view['_message'][] = 'Unesite korisničko ime i lozinku';
    }
    else {
        $sql = "SELECT * FROM korisnici WHERE username='{$username}'";
        $result = mysqli_query($db, $sql);
            $row = mysqli_fetch_assoc($result);
            if ($row != null && $row ['username'] == $username) {


            if ($row['password'] == $password) {
                $_SESSION['login_status'] = 1;
                $_SESSION['usertype'] = $row['usertype'];
                redirect(URL_INDEX);


            }
            else {
                $_page_view['_error'][] = 'Uneti podaci nisu ispravni';
            }
        }
        else
            $_page_view['_error'][] = 'Korisnik ne postoji';
    }
}

$_page_view['page_title'] = 'Prijava';
$_page_view['view_filename'] = './template/view-login.php';
 
?>