<?php   if(isset($_naslov)&&$_naslov == 'najnovije knjige'): ?>
<h1 class="novo">TOP 5 NAJNOVIJIH KNJIGA NASE KNJIZARE!</h1>
<?php  endif; ?>
<container class="product-list">
<?php foreach($_page_view['_data'] as $knjiga):  ?>
<table>
    <tr class="produkt">
        <?php if (isset (($_SESSION['usertype'] )) && ($_SESSION['usertype'] == 'admin')): ?>
        <td>
        <button><a href="<?= URL_INDEX ?>?module=books&action=edit&id=<?= $knjiga['id'] ?>">Edit</a></button> | 
        <button><a href="<?= URL_INDEX ?>?module=books&action=delete&id=<?=$knjiga['id'] ?>">Delete</a></button>
        </td>
        <?php endif ?>
        <td><?= $knjiga['naslov'] ?></td>
        <td><?= $knjiga['autor'] ?></td>
        <td><?= $knjiga['datum'] ?></td>
        <td class="slika">
            <button class="details"><a class="link" href="./index.php?module=bookshop&id=<?=$knjiga['id']?>">Detaljnije</a></button>
            <img src="<?= $knjiga['slika'] ?>">
        </td>
        <td><h2><?= $knjiga['cena'] ?></h2></td>
        <td><?= $knjiga['opis'] ?></td>
    </tr>
</table>
<?php endforeach; ?>
</container>