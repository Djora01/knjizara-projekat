</wrapper>
    <footer>
        <p class="futer1">&copy; <a href="<?php echo URL_INDEX; ?>"> Moja knjiga</p>
    </footer>
</body>
</html>
