<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Naslovna stranica</title>
    <link rel="stylesheet" href="./public/css/style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> <!-- font za lupicu u search baru -->
</head>
<body>
    <above-header>
		<div class="left">
			<a href="<?php echo URL_INDEX; ?>"><img src="./public/images/mojaknjiga.png"></a>
		</div>
		<div class="right">
			<form method="post" action="<?= URL_INDEX ?>?module=search">
				<input type="text" name="search" placeholder="Traži željeni artikl">
				<button type="submit" style="font-size:14px; color:red">
					<i class="fa fa-search"></i>
				</button>
			</form>
		</div>
	</above-header>
    <header>
        <nav class="navbar">
            <ul>
                <li><a href="<?php echo URL_INDEX; ?>">Naslovna</a></li>
                <li><a href="?module=books">Knjige</a></li>
                <li><a href="?module=contact">Kontakt</a></li>

				<?php if (($_SESSION['login_status'] ?? '') == 1): ?>
					<li><a href="?module=login&action=logout">Izloguj se</a></li>
				<?php else: ?>
					<li><a href="?module=login">Prijava</a></li>
				<?php endif; ?>
            </ul>
        </nav>
    </header>
    <wrapper>
