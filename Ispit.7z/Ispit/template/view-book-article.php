<page-news>
    <article>
        <date>
            <?= $article['datum'] ?> <?= $article['datum'] ?>
        </date>
        <article-full>
            <?= $article['opis'] ?>
        </article-full>
    </article>
</page-news>