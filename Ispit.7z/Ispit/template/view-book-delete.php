<form method="POST">
<button name="confirm_action">Izbriši</button>
</form>