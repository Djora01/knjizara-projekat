<page-news>
    <article>
        <form method="post">
            <label>Naslov</label>
            <input type="text" name="naslov" value="<?= $article['naslov'] ?? '' ?>">
            <label>Autor</label>
            <textarea name="autor"><?= $article['autor'] ?? '' ?></textarea>
            <label>Opis</label>
            <textarea name="opis"><?= $article['Opis'] ?? '' ?></textarea>
            <div>
                <button>Pošalji</button>
                <button type="reset">Resetuj</button>
                <button name="cancel" value="1">Otkaži</button>
            </div>
        </form>
    </article>
</page-news>