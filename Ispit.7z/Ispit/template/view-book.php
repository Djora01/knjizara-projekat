<page-book>
    <div class="knjiga-container">
    <div class="knjiga-detalji">
        <div class="knjiga-naslov"><?= $_page_view['_data'][0]['naslov'] ?></div>
        <div class="knjiga-autor"><?= $_page_view['_data'][0]['autor'] ?></div>
        <div class="knjiga-godina"><?= $_page_view['_data'][0]['datum'] ?></div>
        <div class="knjiga-opis"><?= $_page_view['_data'][0]['opis'] ?></div>
    </div>
    <div class="knjiga-slika">
        <img src="<?= $_page_view['_data'][0]['slika'] ?>" alt="Book Cover">
    </div>
    <div class="knjiga-cena">
        <h2><?= $_page_view['_data'][0]['cena'] ?></h2>
    </div>
    </div>
</page-book>