<page-contact>
    <h1 class="naslov-forme">Kontaktirajte nas</h1>
    <form class="kontakt-forma" method="POST">
        <label class="labela-forme" for="ime">Ime osobe:</label><br>
        <input class="polje-tekst" type="text" id="ime" name="ime" required><br>
        <label class="labela-forme" for="email">Email adresa:</label><br>
        <input class="polje-email" type="email" id="email" name="email" required><br>
        <label class="labela-forme" for="poruka">Kratka poruka:</label><br>
        <textarea class="polje-poruka" id="poruka" name="poruka" required rows="4" cols="50" maxlength="200"></textarea><br>
        <input class="dugme-slanje" type="submit" name="submit" value="Pošalji">
    </form>
</page-contact>
