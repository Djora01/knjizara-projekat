<page-login>
<?php if (($_SESSION['login_status'] ?? '') == 1): ?>
        <a href="<?= URL_INDEX ?>" class="link">Vrati se na početnu stranu</a>
    <?php else: ?>
        <div class="kontejner">
            <h1 class="naslov">Prijavite se</h1>
            <form method="post" class="forma">
                <label class="tekst">Korisničko ime</label><br>
                <input type="text" class="polje" name="user" value="<?= $_POST['user'] ?? '' ?>" required>
                <p class ="error user-error"></p>
                <label class="tekst">Lozinka</label><br>
                <input type="password" class="polje" name="password" required>
                <p class="error password-error">
                <?php foreach ($_page_view['_error'] as $message): ?>
                <?php echo "{$message}" ?>
                <?php endforeach; ?>
                <button type="submit" class="dugme">Prijavi se</button>
                <p class="success"></p>
            </form>
        </div>
    <?php endif; ?>
</page-login>